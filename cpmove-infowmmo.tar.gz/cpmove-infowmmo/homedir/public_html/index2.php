<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 	
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> <html xmlns="http://www.w3.org/1999/xhtml"> 
<head> <meta name="google-site-verification" content="r_jlhVOGxI_ZesBO3U_pGyUDb1oZ-bUYhk91VRpog0I" /> 
<title>infoway : Web Designing | Web Hosting | Domain | Cheapest Hosting & Domain Service Provider </title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<meta name="copyright" content="www.infowayindia.in" />	 
<meta name="keywords" content="infoway, infowayindia, infowayindia,info, web development company, website applications development, web design , ecommerce solution provider, graphic designers, website designers, application developer lucknow, infoway lucknow"> <meta name="description" content="Infoway is a web development company, website applications development company web hosting and domain registration company in India offering web development, applications development,web hosting, domain registration ecommerce solution and graphic design at an affordable price"> 
<meta name="author" content="infowayindia" /> <meta name="robots" content="index,all" /> 
<meta name="resource-type" content="Public" /> <meta name="classification" content="Internet Services" /> 
<meta name="MSSmartTagsPreventParsing" content="TRUE" /> <meta name="robots" content="ALL" /> <meta name="distribution" content="Global" /> <meta name="rating" content="Safe For Kids" /> 
<meta http-equiv="Content-Language" content="en" /> 
<meta name="language" content="English" /> 
<meta name="doc-type" content="Public" /> 
<meta name="doc-class" content="Living Document" /> 
<meta name="doc-rights" content="Copywritten Work" /> 
<meta name="distribution" content="Global" /> 
<meta http-equiv="imagetoolbar" content="no" /> 
<meta http-equiv="MSThemeCompatible" content="Yes" /> 
<style> 	h2 	{ 	text-shadow: 5px 5px 5px #414141; margin-left:10px; color:#033B73; 	} 	</style> 	<script type="text/javascript" src="popup/jquery.js"></script> <script type="text/javascript" src="popup/jqry.js"></script> <link rel="stylesheet" type="text/css" href="popup/style1.css" /> 	 	<!-- Start WOWSlider.com HEAD section --> 	<link rel="stylesheet" type="text/css" href="engine1/style.css" /> 	<style type="text/css"> 	a#vlb{display:none} 	</style> 	<script type="text/javascript" src="engine1/jquery.js"></script> 	<script type="text/javascript" src="engine1/wowslider.js"></script> 	 	 	<!-- End WOWSlider.com HEAD section --> <script type="text/javascript"> var _gaq = _gaq || []; _gaq.push(['_setAccount', 'UA-31477222-1']); _gaq.push(['_trackPageview']); (function() { var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true; ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s); })(); ` </script> 	 </head> <body style="background:url(images/bg.jpg)"> 	<!-- Start BODY section -->

<div class="main"> <div class="header"><br /> <div class="contact" style="font-size:38px" > <img src="images/letter_head.jpg" alt="" width="234" height="91" /></div> 

<div class="contact1" > <table width="298" border="0" height="50"> <tr> <td width="340"><p><strong>Email: info@infowayindia.in 
Contact Us:+91-879 903 7745</strong> <br /> 

  <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+91-810 319 4076 </strong> </p> 
</td> 
</tr> 
</table> 
</div> 
</div>  
<br />
<br />
<div class="menu" align="center" style="color:#FFF"><table width="100%" height="38" border="0"><tr> <td> <div class="menu1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.html" style="color:#FFF">HOME</a>&nbsp;&nbsp;| </div> <div class="menu1">&nbsp;&nbsp;<a href="" style="color:#FFF"><a href="aboutus.html" style="color:#FFF">ABOUT US</a>&nbsp;&nbsp;|</div><div class="menu1">&nbsp;&nbsp;<a href="client.html" style="color:#FFF">CLIENT</a>&nbsp;&nbsp;|</div> <div class="menu1">&nbsp;&nbsp;<a href="services.html" style="color:#FFF">SERVICES</a>&nbsp;&nbsp;|</div><div class="menu1">&nbsp;&nbsp; <a href="hosting.html" style="color:#FFF" >WEB HOSTING</a>&nbsp;&nbsp;|</div><div class="menu1">&nbsp;&nbsp;<a href="Domain.html" style="color:#FFF">DOMAIN</a>&nbsp;&nbsp;|</div> <div class="menu1">&nbsp;&nbsp; <a href="contact.html" style="color:#FFF" >CONTACT</a> &nbsp;&nbsp;</div></td></tr></table> </div> <div id="wowslider-container1" style="margin-top:5px"> 	<div class="ws_images"> <span><img src="data1/images/1.jpg" alt="1" title="Start your Business with us" id="wows0"/></span> <span><img src="data1/images/2.jpg" alt="2" title="Web Designing" id="wows1"/></span> <span><img src="data1/images/3.jpg" alt="3" title="Get Your own Domain Name" id="wows2"/></span> <span><img src="data1/images/5.jpg" alt="4" title="Web Hosting" id="wows3"/></span> <span><img src="data1/images/7.jpg" alt="5" title="24X7 Support" id="wows4"/></span> <span><img src="data1/images/8.jpg" alt="8" title="Be a part of us" id="wows5"/></span> </div> 

</div>   <div style="width:100%;height:130px; margin-top:10px; border-top:1px solid #CCCCCC " > <a href="#" class="vlightbox1" > <div id="poduct" align="center"> Web Designing <br />& <br/> Development </div> </a> <a href="hosting.html"> <div id="poduct1" align="center">Web <br /> Hosting <br /> <span style="font-size:17px"> Linux Hosting | Windows Hosting </span></div></a> <a href="Domain.html"> <div id="poduct2" align="center"> Domain <br /> Registration <br /> <span style="font-size:16px"> .COM | .NET | .IN </span> </div></a> <a href="antivirus.html"> <div id="poduct3" align="center"> Anti-Virus <br /> Dealer <br /> <span style="font-size:17px"> Net Protector | Trend Micro</span></div></a> </div> 

<div style="height:auto; width:100%; border-top:1px solid #CCCCCC; color:#666666; padding-top:20px" align="center"> <a href="http://infowayindia.in" target="_parent">Home</a> | <a href="http://infowayindia.in/aboutus.html" target="_parent">About us</a> | <a href="http://infowayindia.in/services.html" target="_parent">Services</a> | <a href="http://infowayindia.in/contact.html">Contact us</a><br /> <a href="http://infowayindia.in/hosting.html"> Web Hosting </a> | <a href="http://infowayindia.in/hosting.html">Linux Hosting </a> | <a href="http://infowayindia.in/hosting.html">Windows Hosting </a> | <a href="http://infowayindia.in/hosting.html">Junior Hosting </a>  | <a href="http://infowayindia.in/hosting.html"> Standard Hosting </a>| <a href="http://infowayindia.in/hosting.html">Multi Domain Hosting </a>| <a href="http://royinfoway.in">Domain </a> <br /> 

Copy right &copy; 2013 All right Reserved | <a href="http://www.infowayindia.in" target="_parent">www.infowayindia.in <br /> 

 </a> <br /></div></div><br /> <script type="text/javascript" src="engine1/script.js"></script> 	 </body> </html>